export class Stock {
    companyName: string = "";
    companyCode: string = "";
    stockPrice: number = 0;
}


