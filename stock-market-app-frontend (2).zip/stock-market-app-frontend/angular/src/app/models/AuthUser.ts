export class AuthUser{
    username:string = "";
    password:string="";
}