package com.stockmarketapp.zuulapigateway;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootTest
class ZuulApiGatewayApplicationTests {


}
