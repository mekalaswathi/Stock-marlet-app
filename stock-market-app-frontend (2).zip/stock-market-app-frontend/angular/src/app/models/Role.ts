export class Role{
    authority:string="";
}