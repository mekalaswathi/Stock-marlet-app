export class User{
    id:string="";
    valid:boolean = false;
    name:string = "";
    username:string = "";
    email:string="";
    phone?:number=0;
    password:string="";
    role:string="";
}