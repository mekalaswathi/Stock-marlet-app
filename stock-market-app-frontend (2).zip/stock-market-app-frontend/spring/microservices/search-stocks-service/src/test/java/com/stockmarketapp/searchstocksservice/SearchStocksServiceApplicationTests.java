package com.stockmarketapp.searchstocksservice;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SearchStocksServiceApplicationTests {

}
