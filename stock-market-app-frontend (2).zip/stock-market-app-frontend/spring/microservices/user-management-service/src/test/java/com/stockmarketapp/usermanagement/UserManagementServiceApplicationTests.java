package com.stockmarketapp.usermanagement;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagementServiceApplicationTests {


}
